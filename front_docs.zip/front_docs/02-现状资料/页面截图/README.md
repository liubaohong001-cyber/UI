# 页面截图说明

本目录下的截图已于 `2026-03-31` 本地自动生成。

## 当前已提供

- `legacy-概览-首页.png`
- `legacy-创建视频-顶部.png`
- `legacy-创建视频-后处理区.png`
- `legacy-任务队列-首页.png`
- `legacy-任务队列-详情弹窗.png`
- `legacy-脚本工作台-首页.png`
- `legacy-音色库-首页.png`
- `legacy-素材库-案例列表.png`
- `legacy-素材库-案例详情.png`
- `legacy-素材库-AI分析结果弹窗.png`
- `legacy-字体管理-首页.png`
- `legacy-BGM库-首页.png`
- `legacy-数据统计-首页.png`
- `legacy-设置-首页.png`
- `new-概览-首页.png`
- `new-创作台-首页.png`
- `new-任务队列-首页.png`

## 截图方式说明

- 通过本地启动 `frontend/` 与 `frontend_new/` 后自动抓取
- 为保证页面稳定出图，接口层使用本地 mock 数据拦截
- 这批图主要用于给乙方理解页面结构、布局密度、模块范围

## 如果你还想继续补

建议后续再补两类：

- 空态截图
- 你认为最丑、最乱、最影响演示的页面局部截图
