# BGM 库

## 页面目的

维护背景音乐资产，支持分类、试听和批量上传。

## 数据来源

- `GET /api/v2/bgm/list`
- `POST /api/v2/bgm/upload`
- `POST /api/v2/bgm/upload-batch`
- `DELETE /api/v2/bgm/{track_id}`

## 页面规则

- 音乐试听应足够直接
- 风格分类和标签应该容易筛选
- 批量上传要有明确进度和失败反馈
