# New UI 说明

## 当前状态

`frontend_new/` 是并行版本，生产环境路径为 `/new`。

当前实际挂载页面只有：

- `/new/`
- `/new/create`
- `/new/queue`

## 当前差异

- 使用顶部导航，而不是 legacy 的左侧导航
- 结构更轻，但覆盖范围远小于 legacy
- 从 legacy 访问 `/new/*` 会跳转到真实 New UI

## 需要设计团队确认

- 新版是否要继续保留独立入口
- 还是直接作为全平台唯一 UI 方案
