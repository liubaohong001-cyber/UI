# 接口说明

## 说明

这份接口文档不是后端全量 OpenAPI 的逐字段镜像，而是按“前端 UI/UX 重构”需要整理的可用接口集。

重点覆盖：

- 页面当前真正用到的接口
- 关键请求字段
- 关键响应字段
- 状态与文件路径约定
- mock 数据映射

## 当前接口基础约定

- Base URL：`/api`
- WebSocket：`/ws/progress`
- 静态文件前缀：
  - `/uploads`
  - `/outputs`
  - `/cache`

## 当前后端模块

- queue
- workbench
- script
- tts
- video
- broll
- settings
- v2（fonts / bgm / cover / subtitle 等）
- publish

## 使用建议

- 乙方前端先对接 `06-mock数据/`
- 内部联调时再逐模块切真实接口
- 如果最终只让乙方做页面，不需要把所有接口都交给乙方
