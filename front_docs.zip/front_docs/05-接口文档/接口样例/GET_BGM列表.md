# GET /api/v2/bgm/list

## 用途

读取 BGM 库列表。

## 响应示例

见 `06-mock数据/bgm/list.success.json`
