# GET /api/broll/cases/{case_id}/videos

## 用途

获取某个案例下的 Broll 素材列表。

## 响应示例

```json
{
  "success": true,
  "case_name": "护肤爆款案例",
  "scenes": [
    "产品特写",
    "上脸演示"
  ],
  "videos": [
    {
      "id": "broll_001",
      "filename": "essence-closeup.mp4",
      "path": "cases/case_beauty_001/broll/essence-closeup.mp4",
      "full_path": "/uploads/cases/case_beauty_001/broll/essence-closeup.mp4",
      "case_id": "case_beauty_001",
      "scene": "产品特写",
      "duration": 8.3,
      "tags": [
        "滴管",
        "高光"
      ],
      "description": "精华液滴管质地展示",
      "analysis_status": "needs_review",
      "auto_tags": [
        "产品特写",
        "液体流动"
      ],
      "video_content": [
        "滴管吸取精华",
        "瓶身特写"
      ],
      "scenes": [],
      "needs_review": true
    }
  ]
}
```
