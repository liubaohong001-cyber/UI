# GET /api/queue/status

## 用途

获取任务队列概览，用于概览页、任务队列页、数据统计页。

## 响应示例

```json
{
  "success": true,
  "total_tasks": 42,
  "pending_tasks": 5,
  "processing_tasks": 3,
  "completed_tasks": 31,
  "failed_tasks": 3,
  "queue_length": 8,
  "active_tts_jobs": 1,
  "active_lipsync_jobs": 2,
  "avg_processing_time": 168
}
```
