# GET /api/queue/tasks

## 用途

获取任务列表，用于概览页最近活动和任务队列表格。

## 常见查询参数

- `status`
- `limit`

## 响应示例

```json
{
  "success": true,
  "tasks": [
    {
      "id": "task_demo_001",
      "status": "processing",
      "stage": "lipsync",
      "priority": 2,
      "queue_position": 1,
      "progress": 67,
      "created_at": "2026-03-31T10:00:00+08:00",
      "updated_at": "2026-03-31T10:04:00+08:00",
      "script_content": "这是一个示例脚本",
      "config": {
        "voice_id": "voice_qwen_female_01",
        "speed": 1,
        "emotion": "neutral",
        "template_selection_mode": "specific",
        "enable_cache": true,
        "retry_count": 1
      },
      "metadata": {},
      "results": {
        "audio_path": "/cache/tts/demo.mp3"
      },
      "errors": []
    }
  ],
  "total": 1
}
```
