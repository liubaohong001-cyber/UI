# GET /api/tts/voices

## 用途

获取音色列表。

## 响应示例

```json
[
  {
    "id": "voice_qwen_female_01",
    "name": "知性女声",
    "gender": "female",
    "description": "适合护肤、知识口播",
    "is_cloned": false,
    "provider": "qwen"
  },
  {
    "id": "voice_clone_host_01",
    "name": "主播克隆声线",
    "gender": "female",
    "description": "来自品牌主播样本",
    "is_cloned": true,
    "provider": "minimax"
  }
]
```
