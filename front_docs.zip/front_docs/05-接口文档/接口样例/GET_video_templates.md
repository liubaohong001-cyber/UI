# GET /api/video/templates

## 用途

获取人像模板列表，用于创建视频和素材库。

## 查询参数

- `case_id`
- `include_analysis_details`

## 响应示例

```json
{
  "success": true,
  "templates": [
    {
      "id": "tpl_host_001",
      "name": "主播正面口播",
      "category": "室内正面",
      "duration": 32.4,
      "path": "video_templates/host-front-01.mp4",
      "thumbnail": "video_templates/thumbs/host-front-01.jpg",
      "tags": [
        "稳定",
        "近景"
      ],
      "analysis_status": "completed",
      "auto_tags": [
        "正面",
        "稳定口播"
      ],
      "needs_review": false
    }
  ]
}
```
