# GET /api/workbench/cases

## 用途

获取案例列表，用于创建视频、脚本工作台、素材库。

## 响应示例

```json
[
  {
    "id": "case_beauty_001",
    "name": "护肤爆款案例",
    "description": "面向 25-35 岁女性的精华液投流案例",
    "industry": "美妆护肤",
    "product": "精华液",
    "target_audience": "25-35岁城市女性",
    "key_selling_points": [
      "提亮肤色",
      "淡化细纹",
      "温和不刺激"
    ],
    "brand_keywords": [
      "科学护肤",
      "温和修护"
    ],
    "strategy_tags": [
      "痛点切入",
      "结果前置"
    ],
    "script_count": 18,
    "quality_script_count": 6,
    "broll_count": 24,
    "brand_voice": "专业但不生硬",
    "created_at": "2026-03-20T09:00:00+08:00",
    "updated_at": "2026-03-31T09:00:00+08:00"
  }
]
```
