# GET /api/queue/tasks

## 用途

读取任务列表。

## 请求参数

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| status | string | 否 | 状态筛选 |
| limit | number | 否 | 默认 100 |
| offset | number | 否 | 默认 0 |

## 响应示例

```json
{
  "success": true,
  "tasks": [
    {
      "id": "task-001",
      "status": "completed",
      "stage": "complete",
      "priority": 2,
      "queue_position": 0,
      "progress": 100,
      "created_at": "2026-03-31T10:00:00",
      "updated_at": "2026-03-31T10:04:20",
      "script_content": "今天教你 30 秒看懂喷漆修复为什么差价会这么大。",
      "title": "喷漆修复差价为什么这么大",
      "content": "30 秒讲明白为什么有人报价 99，有人报价 999。",
      "output_path": "/outputs/projects/2026-03-31/demo/output.mp4",
      "config": {
        "voice_id": "female-news",
        "speed": 1,
        "emotion": "neutral",
        "template_selection_mode": "agent"
      },
      "metadata": {},
      "results": {
        "output_path": "/outputs/projects/2026-03-31/demo/output.mp4"
      },
      "errors": []
    }
  ],
  "total": 1
}
```
