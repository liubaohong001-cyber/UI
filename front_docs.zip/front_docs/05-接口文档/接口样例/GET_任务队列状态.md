# GET /api/queue/status

## 用途

读取队列汇总状态，用于概览页、任务队列页、数据统计页。

## 请求参数

无

## 响应示例

```json
{
  "success": true,
  "total_tasks": 18,
  "pending_tasks": 5,
  "processing_tasks": 3,
  "completed_tasks": 9,
  "failed_tasks": 1,
  "queue_length": 8,
  "active_tts_jobs": 2,
  "active_lipsync_jobs": 1,
  "avg_processing_time": 146.2
}
```
