# GET /api/v2/fonts/list

## 用途

读取字体库列表。

## 响应示例

见 `06-mock数据/fonts/list.success.json`
