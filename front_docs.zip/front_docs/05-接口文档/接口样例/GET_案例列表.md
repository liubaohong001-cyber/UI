# GET /api/workbench/cases

## 用途

读取案例列表，供创建视频、脚本工作台、素材库使用。

## 响应示例

```json
[
  {
    "id": "case-paint-001",
    "name": "喷漆修复",
    "description": "汽车喷漆与局部修复案例",
    "industry": "汽车后市场",
    "product": "局部喷漆修复",
    "target_audience": "车主",
    "key_selling_points": [
      "当天可交付",
      "色差控制稳定"
    ],
    "brand_keywords": [
      "专业",
      "透明报价"
    ],
    "strategy_tags": [
      "价格对比",
      "避坑"
    ],
    "script_count": 12,
    "selling_point_count": 5,
    "broll_count": 26,
    "ip_persona": "10 年汽车美容门店老板",
    "brand_voice": "直接、专业、不绕弯",
    "created_at": "2026-03-20T09:00:00",
    "updated_at": "2026-03-31T09:30:00"
  }
]
```
