# GET /api/video/templates

## 用途

读取指定案例下的人像模板列表。

## 请求参数

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| case_id | string | 否 | 案例 ID |
| include_analysis_details | boolean | 否 | 是否带上分析详情 |

## 响应示例

见 `06-mock数据/templates/list.success.json`
