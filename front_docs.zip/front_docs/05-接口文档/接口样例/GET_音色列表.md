# GET /api/tts/voices

## 用途

读取音色列表。

## 响应示例

```json
[
  {
    "id": "female-news",
    "name": "新闻女声",
    "gender": "female",
    "description": "清晰、标准、适合资讯口播",
    "is_cloned": false,
    "provider": "minimax"
  }
]
```
