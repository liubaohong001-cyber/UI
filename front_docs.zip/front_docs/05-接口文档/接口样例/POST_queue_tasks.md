# POST /api/queue/tasks

## 用途

提交单个视频任务。

## 请求示例

```json
{
  "script_content": "这是一个示例脚本",
  "case_id": "case_beauty_001",
  "priority": 2,
  "config": {
    "voice_id": "voice_qwen_female_01",
    "speed": 1,
    "emotion": "neutral",
    "template_selection_mode": "specific",
    "specific_template_id": "tpl_host_001",
    "enable_cache": true,
    "retry_count": 1
  }
}
```

## 响应示例

```json
{
  "id": "task_demo_002",
  "status": "pending",
  "stage": "queued",
  "priority": 2,
  "queue_position": 4,
  "progress": 0,
  "created_at": "2026-03-31T10:10:00+08:00",
  "updated_at": "2026-03-31T10:10:00+08:00",
  "script_content": "这是一个示例脚本",
  "config": {
    "voice_id": "voice_qwen_female_01",
    "speed": 1,
    "emotion": "neutral",
    "template_selection_mode": "specific",
    "specific_template_id": "tpl_host_001",
    "enable_cache": true,
    "retry_count": 1
  },
  "metadata": {},
  "results": {},
  "errors": []
}
```
