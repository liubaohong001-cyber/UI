# POST /api/script/generate

## 用途

基于案例和策略标签生成多条脚本变体。

## 请求示例

```json
{
  "case_id": "case_beauty_001",
  "strategy_tags": [
    "痛点切入",
    "结果前置"
  ],
  "variation_count": 3,
  "scene_type": "hard_ad",
  "duration": "30-60s"
}
```

## 响应示例

```json
{
  "success": true,
  "variations": [
    {
      "id": "script_var_001",
      "content": "别再盲目叠护肤品了，先把暗沉和细纹这两个核心问题解决。",
      "style": "hard_ad",
      "confidence": 0.91,
      "title": "细纹暗沉一起打",
      "publish_content": "适合熬夜暗沉肌的一条精华选品逻辑"
    }
  ],
  "tokens_used": 1260,
  "system_prompt": "..."
}
```
