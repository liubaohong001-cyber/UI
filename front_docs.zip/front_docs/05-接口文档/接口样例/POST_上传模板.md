# POST /api/video/templates/upload

## 用途

上传单个人像模板视频。

## 请求方式

`multipart/form-data`

## 常见字段

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| file | file | 是 | 模板视频文件 |
| case_id | string | 否 | 所属案例 |
| category | string | 否 | 分类 |

## 响应示例

见 `06-mock数据/templates/upload.success.json`
