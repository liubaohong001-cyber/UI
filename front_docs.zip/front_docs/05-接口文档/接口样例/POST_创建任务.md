# POST /api/queue/tasks

## 用途

创建单个视频任务。

## 请求示例

```json
{
  "script_content": "今天教你 30 秒看懂喷漆修复为什么差价会这么大。",
  "case_id": "case-paint-001",
  "priority": 2,
  "config": {
    "voice_id": "female-news",
    "speed": 1,
    "emotion": "neutral",
    "voice_volume": 1,
    "template_selection_mode": "agent",
    "lipsync_preset": "balanced",
    "cover": {
      "enabled": true,
      "mode": "remotion",
      "title": "喷漆差价为什么这么大",
      "subtitle": "30 秒讲明白",
      "style": "douyin",
      "cover_duration": 6
    },
    "subtitle": {
      "enabled": true,
      "style_preset": "youshe_title_black",
      "creative_overlay_enabled": true,
      "creative_overlay_style": "auto"
    },
    "bgm": {
      "enabled": true,
      "bgm_id": "bgm-001",
      "volume": 0.25
    },
    "broll": {
      "enabled": true,
      "case_id": "case-paint-001",
      "max_inserts": 3,
      "min_segment_duration": 3
    }
  }
}
```

## 响应示例

见 `06-mock数据/queue/task.create.success.json`
