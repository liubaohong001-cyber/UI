# POST /api/script/generate

## 用途

基于案例、策略标签和生成模式，输出多条脚本变体。

## 请求示例

```json
{
  "case_id": "case-paint-001",
  "strategy_tags": [
    "价格对比",
    "避坑"
  ],
  "variation_count": 3,
  "reference_count": 3,
  "scene_type": "hard_ad",
  "generation_mode": "fresh",
  "duration": "15-30s",
  "temperature": 0.9,
  "top_p": 0.9,
  "max_tokens": 3000
}
```

## 响应示例

见 `06-mock数据/workbench/script.generate.success.json`
