# mock 映射表

## 概览

- 队列状态：`queue/status.success.json`
- 最近任务：`queue/tasks.list.success.json`
- 配额：`settings/quotas.success.json`

## 创建视频

- 案例：`workbench/cases.list.success.json`
- 脚本生成：`workbench/script.generate.success.json`
- 模板：`templates/list.success.json`
- B-roll 插入点预览：`broll/preview-insert-points.success.json`
- 字体：`fonts/list.success.json`
- BGM：`bgm/list.success.json`
- 提示词：`settings/prompts.success.json`

## 任务队列

- 列表正常态：`queue/tasks.list.success.json`
- 列表空态：`queue/tasks.list.empty.json`
- 已完成详情：`queue/task.detail.completed.json`
- 失败详情：`queue/task.detail.failed.json`

## 脚本工作台

- 案例列表：`workbench/cases.list.success.json`
- 案例详情：`workbench/cases.detail.success.json`
- 候选脚本：`workbench/candidates.list.success.json`
- 生成结果：`workbench/script.generate.success.json`

## 素材库

- 人像模板：`templates/list.success.json`
- 模板分析结果：`templates/analysis-status.completed.json`
- B-roll 列表：`broll/list.success.json`

## 音色库

- 音色列表：`voices/list.success.json`
- 试听生成：`voices/generate.success.json`
- 设计音色：`voices/design.success.json`
